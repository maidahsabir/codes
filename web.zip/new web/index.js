;(function($) {
    $(function() {
      $('nav ul li > a:not(:only-child)').click(function(e) {
        $(this)
          .siblings('.nav-dropdown')
          .slideToggle()
        $('.nav-dropdown')
          .not($(this).siblings())
          .hide()
        e.stopPropagation()
      })
      $('html').click(function() {
        $('.nav-dropdown').hide()
      })
      // Toggle open and close nav styles on click
      $('#nav-toggle').click(function() {
        $('nav ul').slideToggle();
      });
      $('#nav-toggle').on('click', function() {
        this.classList.toggle('active')
      })
    })
  })(jQuery)
//   .............................
$('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    dots:false,
    nav:true,
    mouseDrag:false,
    autoplay:true,
    animateOut: 'slideOutUp',
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
});
// ............................
class Slider
{
  constructor(config)
  {
    // On récupère la config passée en paramètre et on lui affecte des valeur par défaut si nécessaire
    this.config = {};
    this.config.domTarget = config.domTarget || '.slider',
      this.config.transitionType = config.transitionType || 'random';
    this.config.transitionTimer = config.transitionTimer || 600;
    this.config.autoSlideTimer = config.autoSlideTimer || 4000;
    this.config.picList = config.picList || [];

    // On déclare l'état du slider à "inactif"
    this.isActive = false;

    // On récupère l'élément DOM correspondant à la racine de notre slider
    this.domElement = document.querySelector(this.config.domTarget);

    // On ajoute les animations potentielles
    this.direction = {};
    this.direction.up = this.direction[0] = 'translateY(-100%)';
    this.direction.down = this.direction[1] = 'translateY(100%)';
    this.direction.left = this.direction[2] = 'translateX(-100%)';
    this.direction.right = this.direction[3] = 'translateX(100%)';

    // On charge le contenu
    this.loadContent();
  }

  loadContent()
  {
    // On vérifie que l'élément DOM existe
    if(!this.domElement) throw "Slider - L'élément spécifié est introuvable";

    // Ajout du div qui contiendra les boutons de navigation
    let buttonContainer = document.createElement('div');
    buttonContainer.classList.add('slider-buttons');
    this.domElement.appendChild(buttonContainer);

    this.config.picList.forEach((slide, index) =>
                                {
      // Ajout des slides
      let slideContainer = document.createElement('div');
      slideContainer.setAttribute('data-index', index);
      slideContainer.classList.add('slider-pics');
      slideContainer.style.backgroundImage = `url(${slide.path})`;
      slideContainer.innerHTML = slide.content;
      slideContainer.style.transition = `transform ${this.config.transitionTimer}ms ease-in-out`;
      this.domElement.appendChild(slideContainer);

      // Ajout des boutons
      let button = document.createElement('button');
      button.setAttribute('data-index', index);
      buttonContainer.appendChild(button);

      // Action des boutons
      button.addEventListener('click', event =>
                              {
        // On vérifie que l'animation du slider est terminée avant de pouvoir cliquer
        if(!event.target.classList.contains('active') && !this.isActive)
        {
          // On retire la classe "active" des boutons
          this.buttonList.forEach((element) => element.classList.remove('active'));

          // On affecte la classe "active" uniquement au bouton cliqué
          event.target.classList.add('active');

          // On passe l'état du slider à "actif"
          this.isActive = true;

          // On affiche le slide correspondant au bouton cliqué
          this.showSlide(event.target.getAttribute('data-index'));
        }
      })
    });

    // On stock notre liste de bouton et on clique sur le premier élément
    this.buttonList = this.domElement.querySelectorAll('.slider-buttons button');
    this.buttonList[0].click();
  }

  showSlide(index)
  {
    // On interrompt l'intervalle
    if(this.interval) clearInterval(this.interval);

    // On doit rechercher nos élements à chaque fois car leur ordre est modifié
    let firstSlide = this.domElement.querySelectorAll('.slider-pics')[0];
    let lastSlide = this.domElement.querySelectorAll('.slider-pics')[this.config.picList.length - 1];
    let currentSlide = this.domElement.querySelector(`.slider-pics[data-index="${index}"]`);

    // On place le nouvel élément à afficher en derniere position
    this.domElement.insertBefore(currentSlide, lastSlide);

    // Si la transition est dans la liste on l'affiche, sinon on lance une transition aléatoire
    lastSlide.style.transform = this.direction[this.config.transitionType] 
    || this.direction[Math.floor(Math.random() * 4)];

    setTimeout(() =>
               {
      // Une fois le nouvel élément affiché, on replace correctement l'ancien en première position
      lastSlide.style.transform = 'translate(0%)';
      this.domElement.insertBefore(lastSlide, firstSlide);

      // On repasse l'état du slider en "inactif"
      this.isActive = false;

      // On réactive l'intervalle (slide automatique)
      this.interval = setInterval(() =>
                                  {
        // On clique sur le bouton suivant (ou le premier si c'est nécessaire)
        // On multiplie index par 1 pour forcer sa conversion en int
        let nextSlide = index*1+1 < this.config.picList.length ? index*1+1 : 0;
        this.buttonList[nextSlide].click();

      }, this.config.autoSlideTimer);

    }, this.config.transitionTimer);
  }
}

let slider = new Slider(
{
    domTarget : '.slider',
    picList :
    [
      { path : 'https://i.imgur.com/q0zhEN8.jpg', content : '<h3>Super slide #1</h3>' },
      { path : 'https://i.imgur.com/EEbQdkZ.jpg', content : '<h3>Super slide #2</h3>' },
      { path : 'https://i.imgur.com/fmuSAnc.jpg', content : '<h3>Super slide #3</h3>' },
      { path : 'https://i.imgur.com/XDc5xtl.jpg', content : '<h3>Super slide #4</h3>' },
    ],
});
// .........................
(function($){
    
	// transition checker
	var transitionProp = (function(){
        var el = document.createElement('fake');
        var vendors = [ 'webkit', 'moz', 'ms', 'o' ];
        console.log('transitionの設定', el.style);

        for (var i in vendors) {
            if (el.style[ vendors[i] + 'transition' ] !== undefined) {
                return vendors[i] + 'transition';
            }
        }
        return 'transition';
    })();
	
	// Slider Obj
	var Slider = (function(){
		// DOM and settings
		var $slider = $('#slider'),
            $slide = $slider.find('>*'),
            slideLength = $slide.length,
            $slideBtn = $('.slider-nav_btn'),
            $slideBtnFwd = $('.slider-nav_btn.forward'),
            // $slideBtnBack = $('.slider-nav_btn.back'),
            currentActive = 0, //１枚目
            animateClass = 'animate',
            activeClass = 'active',
            outClass = 'out',
            inClass = 'in',
            nextAction,
            nextId,
            animating = false,
            interval = 6000,
            timerID;
        
            
        // getter and setter
        // =================
		// アクティブスライド管理
		function set_current_id(id) {
			currentActive = id;
		}
		function get_current_id() {
			return currentActive;
		}
		
		// 次のアクション管理
		function set_next_action(action) {
			nextAction = action;
		}
		function get_next_action() {
			return nextAction;
		}
		
		// 次のスライド管理
		function set_next_id(next) {
			nextId = next;
		}
		function get_next_id() {
			return nextId;
		}
		
		// アニメーションフラグ管理
		function set_animation_flag(flag) {
			animating = flag;
		}
		function get_animation_flag() {
			return animating;
        }
        
        // タイマーID管理
        function set_animation_timer(id) {
            timerID = id;
        }
        function get_animation_timer() {
            return timerID;
        }
        // タイマー制御
		function start_timer() {
			set_animation_timer(setTimeout(auto_trigger_action, interval));
		}
		function clear_timer(id) {
			clearTimeout(id);
		}
		
		// 次のIDをチェックするのみ関数(ボタン押下後にしか呼び出さない)
		function next_id_checker() {
			var _action = get_next_action(),
                activeId = get_current_id(),
                nextId;
					
			// 次のスライドチェック
			// 自動か次ボタン(この条件文の順番は遵守!)
			if( _action === 'forward' ) {
				console.log('次へ');
				// MAXチェック
				// true(内) / false(最後)
				nextId = (activeId < (slideLength-1)) ? ++activeId : 0;
			}
			// 前ボタン
			else {
				console.log('前へ');
				// true(最初) / false(内)
				nextId = ( activeId === 0 ) ? (slideLength-1) : --activeId;
			}
			console.log('次スライド: ', nextId);
			return nextId;
		}
		
		//==================================
		
		// スライドアクション(実際のアニメーション)
		function slide_action() {
            var _action = get_next_action(),
                _activeId = get_current_id(),
                $_currentSlide = $slide.eq(_activeId),
                _nextId = get_next_id(),
                $_nextSlide = $slide.eq(_nextId);
                
					
			// 次へボタンの場合
			if(_action === 'forward') {
				$_nextSlide.addClass(animateClass);
				setTimeout(function(){
					$_nextSlide
						.one(transitionProp + 'end', function(){
							$_currentSlide.removeClass(activeClass);
							$(this).removeClass(animateClass);
							after_animation();
						})
						.addClass(activeClass);
					},5);
			}
					
				// 前へボタンの場合
			if(_action === 'back') {
				$_currentSlide.addClass(animateClass);
				$_nextSlide.addClass(activeClass);
				setTimeout(function(){
					$_currentSlide
						.one(transitionProp + 'end', function(){
							$(this).removeClass(animateClass);
							after_animation();
						})
						.removeClass(activeClass);
				},5);
			}
		}
		
		// アニメーション後
		function after_animation() {
			// カレント更新
            set_current_id(get_next_id());
            
			// 次のスライドのテキストイン
			text_in_animation();
			
			// アニメーションフラグとタイマー再発はテキストインアニメーションの後に移動
		}
		
		// スライドアニメーション前
		function before_animation() {
			
			// 次のIDチェック＆ID決定
			set_next_id( next_id_checker() );
			
			// 実際のアニメーション
			slide_action();
		}
		
		
		// テキストアニメーション
		// ================
		// 現在のスライドがアウトする時, 現在のテキストからアウト
		// 且つ次のスライドのテキスト準備
		function text_out_animation() {
			console.log('テキストアウト！');
			var _action = get_next_action(),
                _currentId = get_current_id(),
                _nextId = next_id_checker(),
                $_currentSlide = $slide.eq(_currentId),
                $_nextSlide = $slide.eq(_nextId),
                $_slideTexts = $_currentSlide.find('.slide-text'),
                $_slideTextOne = $($_slideTexts.get(0)),
                $_slideTextsNext = $_nextSlide.find('.slide-text');
            
            // アニメーション準備
			$_slideTexts.addClass(animateClass);
			
			$_slideTextOne.one(transitionProp + 'end', function(){
				$(this).removeClass(animateClass);
				before_animation(); //アニメーション準備
			});
			
			setTimeout(function(){
				if(_action === 'forward') {
					console.log('次のスライドテキストは ', inClass);
					$_slideTexts.addClass(outClass);
					$_slideTextsNext.removeClass(inClass+' '+outClass).addClass(inClass);
				}
				if(_action === 'back') {
					console.log('次のスライドテキストは ', outClass);
					$_slideTexts.addClass(inClass);
					$_slideTextsNext.removeClass(inClass+' '+outClass).addClass(outClass);
				}
			}, 5);
		}
		
		// 次のスライドがインした後、テキストイン
		function text_in_animation() {
			console.log('テキストイン！');
			var _currId = get_current_id(),
                $_currentSlide = $slide.eq(_currId),
                $_slideTexts = $_currentSlide.find('.slide-text'),
                $_slideTextOne = $($_slideTexts.get(0));
            
            // アニメーション準備
			$_slideTexts.addClass(animateClass);
			
			$_slideTextOne.one(transitionProp + 'end', function(){
                console.log('テキストイン終了');
                $_slideTexts.removeClass(animateClass);
                
                // アニメーションフラグ操作(終了)
                set_animation_flag(false);
                // タイマー再発
                start_timer();
            });
			
			setTimeout(function(){
				// あんまよくないけどどっちもに同時対応				
				$_slideTexts.removeClass(inClass+' '+outClass);
			}, 5);
			
		}
		
		
		// 自動トリガー
		function auto_trigger_action() {
			$slideBtnFwd.trigger('click', [true]);
		}
		
		
		// ボタンイベント
		function assign_btn_action() {
			$slideBtn.on('click', function(e,data){
                // アニメーションフラグチェック&操作
                if(get_animation_flag()) return;
                set_animation_flag(true);

                // タイマークリア
                // タイマー操作
                clear_timer(get_animation_timer());
				
				console.log('クリック', data);
				// if(data === true) {
					// console.log('自動トリガーによるクリック');
				// }
				var $btn = $(this);
				
				if( $btn.hasClass('back') ) {
					console.log('前へボタン');
					set_next_action('back');
				}
				if( $btn.hasClass('forward') ) {
					console.log('次へボタン');
					set_next_action('forward');
				}
				
				text_out_animation(); //テキストアウトアニメーション呼び出し
			});
		}
		
		
		function startup_slider() {
			$slider.one(transitionProp + 'end', function(){
				$(this).one(transitionProp + 'end', function(){
					after_init();
				})
				.addClass('ready');
			})
			.removeClass('before');
		}
		
// 		init
		function init() {
			startup_slider();
		}
		function after_init() {
			assign_btn_action();
			start_timer();
		}
		
		return {
			init: init,
		}
		
	})();
	
// 	windowロード後アクション
	$(window).on('load', function(){
		// スライダー発動
		Slider.init();
	});
	
})(jQuery);